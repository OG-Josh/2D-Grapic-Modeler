project files:

fontComboBox.h 18 lines
itemButton.h 35 lines
itemProperty.h 201 lines
about.h 41 lines
arrange.h 18 lines
detailView.h 25 lines
shape.h 122 lines
canvas.h 40 lines
PropertySetting.h 30 lines
contactme.h 27 lines
ellipse.h 32 lines
line.h 55 lines
login.h 34 lines
mainwindow.h 107 lines
polygon.h 29 lines
polyline.h 55 lines
privilege.h 20 lines
rectangle.h 34 lines
text.h 73 lines
vector.h 444 lines
linkedList.h 104 lines
saveFile.h 38 lines
shapeListModel.h 34 lines
sort.h 45 lines
storage.h 18 lines
vectorNode.h 25 lines

fontComboBox.cpp 43 lines
itemButton.cpp 31 lines
itemProperty.cpp 593 lines
about.cpp 32 lines
arrange.cpp 76 lines
detailView.cpp 18 lines
shape.cpp 157 lines
canvas.cpp 51 lines
PropertySetting.cpp 132 lines
contactme.cpp 27 lines
ellipse.cpp 65 lines
line.cpp 78 lines
login.cpp 157 lines
mainwindow.cpp 440 lines
polygon.cpp 64 lines
polyline.cpp 108 lines
rectangle.cpp 79 lines
text.cpp 73 lines
saveFile.cpp 777 lines
shapeListModel.cpp 33 lines
sort.cpp 25 lines
storage.cpp 12 lines

uml: https://github.com/JonasQN/cs1c-class-project/blob/master/ClassProject.png

custom vector were used in the saveFile.h file
