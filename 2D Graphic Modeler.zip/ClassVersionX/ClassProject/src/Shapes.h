/******************************************************************************
 * 
 * Shapes.h
 * 
 * Convinience header for including all shapes.
 * 
 *****************************************************************************/

#ifndef SHAPES_H
#define SHAPES_H



#endif // SHAPES_H
