var searchData=
[
  ['shape',['Shape',['../class_shape.html',1,'']]],
  ['shapelistmodel',['ShapeListModel',['../class_shape_list_model.html',1,'']]],
  ['signinuser',['signinUser',['../class_login.html#af819d90b7b7b0f33faa4305ccf65c437',1,'Login']]],
  ['storage',['Storage',['../struct_storage.html',1,'']]]
];
