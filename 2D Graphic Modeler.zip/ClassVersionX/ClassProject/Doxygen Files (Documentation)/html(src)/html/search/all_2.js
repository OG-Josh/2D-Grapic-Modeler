var searchData=
[
  ['detailview',['DetailView',['../class_detail_view.html',1,'']]]
];
