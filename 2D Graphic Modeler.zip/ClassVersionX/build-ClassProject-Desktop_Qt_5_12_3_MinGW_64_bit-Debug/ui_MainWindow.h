/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <canvas.h>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSave;
    QAction *actionExit;
    QAction *actionAdd_Ellipse;
    QAction *actionAdd_Line;
    QAction *actionAdd_Polygon;
    QAction *actionAdd_Polyline;
    QAction *actionAdd_Rectangle;
    QAction *actionAdd_Text;
    QAction *actionBy_ID;
    QAction *actionAbout;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;
    Canvas *canvas;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuReports;
    QMenu *menuHelp;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QDockWidget *PropDock;
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QComboBox *ShapeList;
    QLabel *label_2;
    QTreeWidget *PropTree;
    QPushButton *remove;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1280, 720);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QString::fromUtf8("actionSave"));
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        actionAdd_Ellipse = new QAction(MainWindow);
        actionAdd_Ellipse->setObjectName(QString::fromUtf8("actionAdd_Ellipse"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/add_ellipse.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/icons/add_ellipse.png"), QSize(), QIcon::Normal, QIcon::On);
        actionAdd_Ellipse->setIcon(icon);
        actionAdd_Line = new QAction(MainWindow);
        actionAdd_Line->setObjectName(QString::fromUtf8("actionAdd_Line"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/add_line.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        actionAdd_Line->setIcon(icon1);
        actionAdd_Polygon = new QAction(MainWindow);
        actionAdd_Polygon->setObjectName(QString::fromUtf8("actionAdd_Polygon"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/add_polygon.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        actionAdd_Polygon->setIcon(icon2);
        actionAdd_Polyline = new QAction(MainWindow);
        actionAdd_Polyline->setObjectName(QString::fromUtf8("actionAdd_Polyline"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/icons/add_polyline.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        actionAdd_Polyline->setIcon(icon3);
        actionAdd_Rectangle = new QAction(MainWindow);
        actionAdd_Rectangle->setObjectName(QString::fromUtf8("actionAdd_Rectangle"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/icons/add_rectangle.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        actionAdd_Rectangle->setIcon(icon4);
        actionAdd_Text = new QAction(MainWindow);
        actionAdd_Text->setObjectName(QString::fromUtf8("actionAdd_Text"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/icons/add_text.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        actionAdd_Text->setIcon(icon5);
        actionBy_ID = new QAction(MainWindow);
        actionBy_ID->setObjectName(QString::fromUtf8("actionBy_ID"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        scrollArea = new QScrollArea(centralWidget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1018, 626));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        canvas = new Canvas(scrollAreaWidgetContents);
        canvas->setObjectName(QString::fromUtf8("canvas"));
        canvas->setMinimumSize(QSize(1000, 500));

        verticalLayout_2->addWidget(canvas);

        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout->addWidget(scrollArea);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1280, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuReports = new QMenu(menuBar);
        menuReports->setObjectName(QString::fromUtf8("menuReports"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);
        PropDock = new QDockWidget(MainWindow);
        PropDock->setObjectName(QString::fromUtf8("PropDock"));
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout_3 = new QVBoxLayout(dockWidgetContents);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label = new QLabel(dockWidgetContents);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_3->addWidget(label);

        ShapeList = new QComboBox(dockWidgetContents);
        ShapeList->setObjectName(QString::fromUtf8("ShapeList"));

        verticalLayout_3->addWidget(ShapeList);

        label_2 = new QLabel(dockWidgetContents);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_3->addWidget(label_2);

        PropTree = new QTreeWidget(dockWidgetContents);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(1, QString::fromUtf8("2"));
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        PropTree->setHeaderItem(__qtreewidgetitem);
        PropTree->setObjectName(QString::fromUtf8("PropTree"));
        PropTree->setMinimumSize(QSize(268, 0));
        PropTree->setColumnCount(2);
        PropTree->header()->setCascadingSectionResizes(true);
        PropTree->header()->setDefaultSectionSize(150);
        PropTree->header()->setStretchLastSection(true);

        verticalLayout_3->addWidget(PropTree);

        remove = new QPushButton(dockWidgetContents);
        remove->setObjectName(QString::fromUtf8("remove"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(remove->sizePolicy().hasHeightForWidth());
        remove->setSizePolicy(sizePolicy);

        verticalLayout_3->addWidget(remove);

        PropDock->setWidget(dockWidgetContents);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), PropDock);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuReports->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuFile->addAction(actionSave);
        menuFile->addSeparator();
        menuFile->addSeparator();
        menuFile->addAction(actionExit);
        menuReports->addAction(actionBy_ID);
        menuHelp->addAction(actionAbout);
        mainToolBar->addAction(actionAdd_Ellipse);
        mainToolBar->addAction(actionAdd_Line);
        mainToolBar->addAction(actionAdd_Polygon);
        mainToolBar->addAction(actionAdd_Polyline);
        mainToolBar->addAction(actionAdd_Rectangle);
        mainToolBar->addAction(actionAdd_Text);
        mainToolBar->addSeparator();

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        actionSave->setText(QApplication::translate("MainWindow", "Save", nullptr));
#ifndef QT_NO_SHORTCUT
        actionSave->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", nullptr));
#endif // QT_NO_SHORTCUT
        actionExit->setText(QApplication::translate("MainWindow", "Exit", nullptr));
        actionAdd_Ellipse->setText(QApplication::translate("MainWindow", "Add Ellipse", nullptr));
#ifndef QT_NO_TOOLTIP
        actionAdd_Ellipse->setToolTip(QApplication::translate("MainWindow", "Add an ellipse", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionAdd_Ellipse->setStatusTip(QApplication::translate("MainWindow", "Add an ellipse", nullptr));
#endif // QT_NO_STATUSTIP
        actionAdd_Line->setText(QApplication::translate("MainWindow", "Add Line", nullptr));
#ifndef QT_NO_TOOLTIP
        actionAdd_Line->setToolTip(QApplication::translate("MainWindow", "Add a line", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionAdd_Line->setStatusTip(QApplication::translate("MainWindow", "Add a line", nullptr));
#endif // QT_NO_STATUSTIP
        actionAdd_Polygon->setText(QApplication::translate("MainWindow", "Add Polygon", nullptr));
#ifndef QT_NO_STATUSTIP
        actionAdd_Polygon->setStatusTip(QApplication::translate("MainWindow", "Add a polygon", nullptr));
#endif // QT_NO_STATUSTIP
        actionAdd_Polyline->setText(QApplication::translate("MainWindow", "Add Polyline", nullptr));
#ifndef QT_NO_STATUSTIP
        actionAdd_Polyline->setStatusTip(QApplication::translate("MainWindow", "Add a polyline", nullptr));
#endif // QT_NO_STATUSTIP
        actionAdd_Rectangle->setText(QApplication::translate("MainWindow", "Add Rectangle", nullptr));
#ifndef QT_NO_STATUSTIP
        actionAdd_Rectangle->setStatusTip(QApplication::translate("MainWindow", "Add a rectangle", nullptr));
#endif // QT_NO_STATUSTIP
        actionAdd_Text->setText(QApplication::translate("MainWindow", "Add Text", nullptr));
#ifndef QT_NO_STATUSTIP
        actionAdd_Text->setStatusTip(QApplication::translate("MainWindow", "Add a text box", nullptr));
#endif // QT_NO_STATUSTIP
        actionBy_ID->setText(QApplication::translate("MainWindow", "By ID", nullptr));
        actionAbout->setText(QApplication::translate("MainWindow", "About", nullptr));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", nullptr));
        menuReports->setTitle(QApplication::translate("MainWindow", "Reports", nullptr));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", nullptr));
        mainToolBar->setWindowTitle(QApplication::translate("MainWindow", "Add Shapes", nullptr));
        PropDock->setWindowTitle(QApplication::translate("MainWindow", "Property Editor", nullptr));
        label->setText(QApplication::translate("MainWindow", "Shapes", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Properties", nullptr));
        remove->setText(QApplication::translate("MainWindow", "Remove Shape", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
