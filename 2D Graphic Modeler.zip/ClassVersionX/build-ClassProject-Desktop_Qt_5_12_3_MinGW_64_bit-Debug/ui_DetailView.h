/********************************************************************************
** Form generated from reading UI file 'DetailView.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DETAILVIEW_H
#define UI_DETAILVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_DetailView
{
public:
    QVBoxLayout *verticalLayout;
    QTextEdit *text;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DetailView)
    {
        if (DetailView->objectName().isEmpty())
            DetailView->setObjectName(QString::fromUtf8("DetailView"));
        DetailView->resize(600, 400);
        verticalLayout = new QVBoxLayout(DetailView);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        text = new QTextEdit(DetailView);
        text->setObjectName(QString::fromUtf8("text"));
        text->setReadOnly(true);
        text->setTabStopDistance(120.000000000000000);

        verticalLayout->addWidget(text);

        buttonBox = new QDialogButtonBox(DetailView);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(DetailView);
        QObject::connect(buttonBox, SIGNAL(accepted()), DetailView, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DetailView, SLOT(reject()));

        QMetaObject::connectSlotsByName(DetailView);
    } // setupUi

    void retranslateUi(QDialog *DetailView)
    {
        DetailView->setWindowTitle(QApplication::translate("DetailView", "Detail Report", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DetailView: public Ui_DetailView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DETAILVIEW_H
