/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QToolBox *toolBox;
    QWidget *loginPage;
    QGroupBox *groupBox;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_username;
    QLabel *label_username_2;
    QLabel *label_username_3;
    QVBoxLayout *verticalLayout;
    QLineEdit *lineEdit_username;
    QLineEdit *lineEdit_password;
    QPushButton *pushButton_login;
    QWidget *signinPage;
    QFrame *frame;
    QPushButton *pushButton_addUser;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_addusername;
    QLineEdit *lineEdit_addUser;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_addpassword;
    QLineEdit *lineEdit_addPass;
    QCheckBox *checkBox_admin;

    void setupUi(QDialog *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QString::fromUtf8("Login"));
        Login->resize(402, 414);
        toolBox = new QToolBox(Login);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        toolBox->setGeometry(QRect(0, 0, 401, 341));
        loginPage = new QWidget();
        loginPage->setObjectName(QString::fromUtf8("loginPage"));
        loginPage->setGeometry(QRect(0, 0, 401, 279));
        groupBox = new QGroupBox(loginPage);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 10, 321, 211));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 40, 281, 153));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_username = new QLabel(layoutWidget);
        label_username->setObjectName(QString::fromUtf8("label_username"));
        QFont font;
        font.setPointSize(9);
        label_username->setFont(font);

        verticalLayout_2->addWidget(label_username);

        label_username_2 = new QLabel(layoutWidget);
        label_username_2->setObjectName(QString::fromUtf8("label_username_2"));
        label_username_2->setFont(font);

        verticalLayout_2->addWidget(label_username_2);

        label_username_3 = new QLabel(layoutWidget);
        label_username_3->setObjectName(QString::fromUtf8("label_username_3"));
        QFont font1;
        font1.setPointSize(10);
        label_username_3->setFont(font1);

        verticalLayout_2->addWidget(label_username_3);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lineEdit_username = new QLineEdit(layoutWidget);
        lineEdit_username->setObjectName(QString::fromUtf8("lineEdit_username"));

        verticalLayout->addWidget(lineEdit_username);

        lineEdit_password = new QLineEdit(layoutWidget);
        lineEdit_password->setObjectName(QString::fromUtf8("lineEdit_password"));

        verticalLayout->addWidget(lineEdit_password);

        pushButton_login = new QPushButton(layoutWidget);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));

        verticalLayout->addWidget(pushButton_login);


        horizontalLayout->addLayout(verticalLayout);

        toolBox->addItem(loginPage, QString::fromUtf8("Log In"));
        signinPage = new QWidget();
        signinPage->setObjectName(QString::fromUtf8("signinPage"));
        signinPage->setGeometry(QRect(0, 0, 401, 279));
        frame = new QFrame(signinPage);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(20, 10, 361, 271));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pushButton_addUser = new QPushButton(frame);
        pushButton_addUser->setObjectName(QString::fromUtf8("pushButton_addUser"));
        pushButton_addUser->setGeometry(QRect(20, 230, 93, 28));
        layoutWidget_2 = new QWidget(frame);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(20, 30, 321, 141));
        verticalLayout_5 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_addusername = new QLabel(layoutWidget_2);
        label_addusername->setObjectName(QString::fromUtf8("label_addusername"));

        verticalLayout_3->addWidget(label_addusername);

        lineEdit_addUser = new QLineEdit(layoutWidget_2);
        lineEdit_addUser->setObjectName(QString::fromUtf8("lineEdit_addUser"));

        verticalLayout_3->addWidget(lineEdit_addUser);


        verticalLayout_5->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_addpassword = new QLabel(layoutWidget_2);
        label_addpassword->setObjectName(QString::fromUtf8("label_addpassword"));

        verticalLayout_4->addWidget(label_addpassword);

        lineEdit_addPass = new QLineEdit(layoutWidget_2);
        lineEdit_addPass->setObjectName(QString::fromUtf8("lineEdit_addPass"));

        verticalLayout_4->addWidget(lineEdit_addPass);


        verticalLayout_5->addLayout(verticalLayout_4);

        checkBox_admin = new QCheckBox(layoutWidget_2);
        checkBox_admin->setObjectName(QString::fromUtf8("checkBox_admin"));

        verticalLayout_5->addWidget(checkBox_admin);

        toolBox->addItem(signinPage, QString::fromUtf8("Sign In"));

        retranslateUi(Login);

        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QDialog *Login)
    {
        Login->setWindowTitle(QApplication::translate("Login", "Log-in Form", nullptr));
        groupBox->setTitle(QString());
        label_username->setText(QApplication::translate("Login", "Username", nullptr));
        label_username_2->setText(QApplication::translate("Login", "Password", nullptr));
        label_username_3->setText(QString());
        pushButton_login->setText(QApplication::translate("Login", "Login", nullptr));
        toolBox->setItemText(toolBox->indexOf(loginPage), QApplication::translate("Login", "Log In", nullptr));
        pushButton_addUser->setText(QApplication::translate("Login", "Make Account!", nullptr));
        label_addusername->setText(QApplication::translate("Login", "Username", nullptr));
        label_addpassword->setText(QApplication::translate("Login", "Password (minimum 8 characters)", nullptr));
        checkBox_admin->setText(QApplication::translate("Login", "Is Admin Accout?", nullptr));
        toolBox->setItemText(toolBox->indexOf(signinPage), QApplication::translate("Login", "Sign In", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
