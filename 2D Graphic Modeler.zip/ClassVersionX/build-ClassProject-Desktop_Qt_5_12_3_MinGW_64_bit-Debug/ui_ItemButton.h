/********************************************************************************
** Form generated from reading UI file 'ItemButton.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ITEMBUTTON_H
#define UI_ITEMBUTTON_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ItemButton
{
public:
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *ItemButton)
    {
        if (ItemButton->objectName().isEmpty())
            ItemButton->setObjectName(QString::fromUtf8("ItemButton"));
        ItemButton->resize(400, 20);
        horizontalLayout = new QHBoxLayout(ItemButton);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer = new QSpacerItem(369, 17, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        retranslateUi(ItemButton);

        QMetaObject::connectSlotsByName(ItemButton);
    } // setupUi

    void retranslateUi(QWidget *ItemButton)
    {
        ItemButton->setWindowTitle(QApplication::translate("ItemButton", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ItemButton: public Ui_ItemButton {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ITEMBUTTON_H
